-- SQL Manager Lite for PostgreSQL 5.2.0.3
-- ---------------------------------------
-- Database  : sge
-- Version   : PostgreSQL 8.4.10, compiled by Visual C++ build 1400, 32-bit

-- --------------------------------------------
-- EXECUTAR PRIMEIRO A CRIA��O DA BASE DE DADOS
-- --------------------------------------------

-- DROP DATABASE sge;

CREATE DATABASE sge
  WITH OWNER = postgres
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'Portuguese_Brazil.1252'
       LC_CTYPE = 'Portuguese_Brazil.1252'
       CONNECTION LIMIT = -1;

-- --------------------------------------------
-- DEPOIS A CRIA��O DOS DEMAIS OBJETOS
-- --------------------------------------------
	   
SET search_path = public, pg_catalog;
SET check_function_bodies = false;
--
-- Structure for table conteudos (OID = 107071) : 
--
CREATE TABLE public.conteudos (
    id bigserial NOT NULL,
    ano integer NOT NULL,
    id_evento bigint NOT NULL,
    ano_evento integer NOT NULL,
    url character varying(2000) NOT NULL,
    titulo character varying(100) NOT NULL
)
WITH (oids = false);
--
-- Structure for table eventos (OID = 107079) : 
--
CREATE TABLE public.eventos (
    id bigint NOT NULL,
    ano integer NOT NULL,
    id_organizador bigint NOT NULL,
    id_tema bigint NOT NULL,
    ano_tema integer NOT NULL,
    data_inicio date NOT NULL,
    data_final date NOT NULL,
    hora_inicio char(5) NOT NULL,
    hora_fim char(5) NOT NULL,
    id_instrutor bigint NOT NULL,
    pago char(1) DEFAULT 'N'::bpchar NOT NULL,
    total_vagas integer NOT NULL,
    vagas_disponiveis integer NOT NULL,
    id_local_evento bigint NOT NULL,
    valor numeric(15,2) DEFAULT 0.00,
    status character varying(10),
    data_inclusao date,
    hora_inclusao time without time zone,
    descricao character varying(2000)
)
WITH (oids = false);
--
-- Definition for sequence eventos_id_seq (OID = 107087) : 
--
CREATE SEQUENCE public.eventos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    MINVALUE 0
    CACHE 1;
--
-- Structure for table inscricoes (OID = 107089) : 
--
CREATE TABLE public.inscricoes (
    id bigserial NOT NULL,
    ano integer NOT NULL,
    id_participante bigint NOT NULL,
    id_evento bigint NOT NULL,
    ano_evento integer NOT NULL,
    data_inscricao date,
    hora_inscricao time without time zone,
    certificadoliberado boolean NOT NULL
)
WITH (oids = false);
--
-- Structure for table instrutores (OID = 107094) : 
--
CREATE TABLE public.instrutores (
    id bigserial NOT NULL,
    nome character varying(70) NOT NULL,
    fonefixo character varying(15),
    celular character varying(15),
    sexo char(1) NOT NULL,
    cpf character varying(14) NOT NULL,
    email character varying(40) NOT NULL,
    cidade character varying(60) NOT NULL,
    uf char(2) NOT NULL,
    cep char(10) NOT NULL,
    numero_endereco character varying(10) NOT NULL,
    complemento_endereco character varying(30),
    senha character varying(50),
    ativo boolean NOT NULL
)
WITH (oids = false);
--
-- Structure for table locais_eventos (OID = 107099) : 
--
CREATE TABLE public.locais_eventos (
    id bigserial NOT NULL,
    nome character varying(70) NOT NULL,
    pessoafj char(1) NOT NULL,
    cpfcnpj character varying(14) NOT NULL,
    fonefixo character varying(15),
    celular character varying(15),
    email character varying(40) NOT NULL,
    cidade character varying(60) NOT NULL,
    uf char(2) NOT NULL,
    cep char(10) NOT NULL,
    numero_endereco character varying(10) NOT NULL,
    complemento_endereco character varying(30),
    ativo boolean NOT NULL,
    senha character varying(50) NOT NULL
)
WITH (oids = false);
--
-- Structure for table presencas (OID = 107104) : 
--
CREATE TABLE public.presencas (
    id bigserial NOT NULL,
    ano integer NOT NULL,
    id_evento bigint NOT NULL,
    ano_evento integer NOT NULL,
    id_participante bigint NOT NULL,
    data date NOT NULL
)
WITH (oids = true);
--
-- Structure for table temas_eventos (OID = 107109) : 
--
CREATE TABLE public.temas_eventos (
    id bigint NOT NULL,
    ano integer NOT NULL,
    nome character varying(100) NOT NULL,
    id_usuario bigint NOT NULL
)
WITH (oids = false);

-- DROP SEQUENCE temas_eventos_id_seq;

CREATE SEQUENCE public.temas_eventos_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE temas_eventos_id_seq OWNER TO postgres;

--
-- Structure for table usuarios (OID = 107114) : 
--
CREATE TABLE public.usuarios (
    id bigserial NOT NULL,
    nome character varying(70) NOT NULL,
    tipousuario char(1) NOT NULL,
    fonefixo character varying(15),
    celular character varying(15),
    sexo char(1) NOT NULL,
    pessoafj char(1) NOT NULL,
    cpfcnpj character varying(14) NOT NULL,
    email character varying(40) NOT NULL,
    cidade character varying(60) NOT NULL,
    uf char(2) NOT NULL,
    cep char(10) NOT NULL,
    numero_endereco character varying(10) NOT NULL,
    complemento_endereco character varying(30),
    senha character varying(50) NOT NULL,
    ativo boolean NOT NULL
)
WITH (oids = false);
--
-- Structure for table locais_eventos_agenda (OID = 107567) : 
--
CREATE TABLE public.locais_eventos_agenda (
    id bigserial NOT NULL,
    ano integer NOT NULL,
    id_evento bigint NOT NULL,
    ano_evento integer NOT NULL,
    id_local_evento bigint NOT NULL,
    data_reserva date NOT NULL,
    hora_inicio char(5) NOT NULL,
    hora_final char(5) NOT NULL,
    dia_semana char(3) NOT NULL,
    num_dia_semana integer DEFAULT 0
)
WITH (oids = false);
--
-- Structure for table usuarios_agenda (OID = 108045) : 
--
CREATE TABLE public.usuarios_agenda (
    id bigint NOT NULL,
    ano integer NOT NULL,
    id_evento bigint NOT NULL,
    ano_evento integer NOT NULL,
    id_usuario bigint NOT NULL,
    data_reserva date NOT NULL,
    hora_inicio char(5) NOT NULL,
    hora_final char(5) NOT NULL,
    dia_semana char(3) NOT NULL,
    num_dia_semana integer DEFAULT 0 NOT NULL
)
WITH (oids = false);

--
-- Definition for sequence usuarios_agenda_id_seq (OID = 108061) : 
--
CREATE SEQUENCE public.usuarios_agenda_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
	
--
-- Definition for index conteudos_pkey (OID = 107151) : 
--
ALTER TABLE ONLY conteudos
    ADD CONSTRAINT conteudos_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index eventos_pkey (OID = 107153) : 
--
ALTER TABLE ONLY eventos
    ADD CONSTRAINT eventos_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index inscricoes_pkey (OID = 107155) : 
--
ALTER TABLE ONLY inscricoes
    ADD CONSTRAINT inscricoes_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index instrutores_cpf_key (OID = 107157) : 
--
ALTER TABLE ONLY instrutores
    ADD CONSTRAINT instrutores_cpf_key
    UNIQUE (cpf);
--
-- Definition for index instrutores_pkey (OID = 107159) : 
--
ALTER TABLE ONLY instrutores
    ADD CONSTRAINT instrutores_pkey
    PRIMARY KEY (id);
--
-- Definition for index locais_eventos_cpfcnpj_key (OID = 107161) : 
--
ALTER TABLE ONLY locais_eventos
    ADD CONSTRAINT locais_eventos_cpfcnpj_key
    UNIQUE (cpfcnpj);
--
-- Definition for index locais_eventos_pkey (OID = 107163) : 
--
ALTER TABLE ONLY locais_eventos
    ADD CONSTRAINT locais_eventos_pkey
    PRIMARY KEY (id);
--
-- Definition for index presencas_pkey (OID = 107165) : 
--
ALTER TABLE ONLY presencas
    ADD CONSTRAINT presencas_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index temas_eventos_nome_key (OID = 107167) : 
--
ALTER TABLE ONLY temas_eventos
    ADD CONSTRAINT temas_eventos_nome_key
    UNIQUE (nome);
--
-- Definition for index temas_eventos_pkey (OID = 107169) : 
--
ALTER TABLE ONLY temas_eventos
    ADD CONSTRAINT temas_eventos_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index usuarios_pkey (OID = 107171) : 
--
ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_pkey
    PRIMARY KEY (id);
--
-- Definition for index conteudos_id_evento_fkey (OID = 107173) : 
--
ALTER TABLE ONLY conteudos
    ADD CONSTRAINT conteudos_id_evento_fkey
    FOREIGN KEY (id_evento, ano_evento) REFERENCES eventos(id, ano);
--
-- Definition for index eventos_id_instrutor_fkey (OID = 107178) : 
--
ALTER TABLE ONLY eventos
    ADD CONSTRAINT eventos_id_instrutor_fkey
    FOREIGN KEY (id_instrutor) REFERENCES instrutores(id);
--
-- Definition for index eventos_id_organizador_fkey (OID = 107183) : 
--
ALTER TABLE ONLY eventos
    ADD CONSTRAINT eventos_id_organizador_fkey
    FOREIGN KEY (id_organizador) REFERENCES usuarios(id);
--
-- Definition for index eventos_id_tema_fkey (OID = 107188) : 
--
ALTER TABLE ONLY eventos
    ADD CONSTRAINT eventos_id_tema_fkey
    FOREIGN KEY (id_tema, ano_tema) REFERENCES temas_eventos(id, ano);
--
-- Definition for index inscricoes_id_evento_fkey (OID = 107193) : 
--
ALTER TABLE ONLY inscricoes
    ADD CONSTRAINT inscricoes_id_evento_fkey
    FOREIGN KEY (id_evento, ano_evento) REFERENCES eventos(id, ano);
--
-- Definition for index inscricoes_id_participante_fkey (OID = 107198) : 
--
ALTER TABLE ONLY inscricoes
    ADD CONSTRAINT inscricoes_id_participante_fkey
    FOREIGN KEY (id_participante) REFERENCES usuarios(id);
--
-- Definition for index presencas_id_evento_fkey (OID = 107203) : 
--
ALTER TABLE ONLY presencas
    ADD CONSTRAINT presencas_id_evento_fkey
    FOREIGN KEY (id_evento, ano_evento) REFERENCES eventos(id, ano);
--
-- Definition for index presencas_id_participante_fkey (OID = 107208) : 
--
ALTER TABLE ONLY presencas
    ADD CONSTRAINT presencas_id_participante_fkey
    FOREIGN KEY (id_participante) REFERENCES usuarios(id);
--
-- Definition for index locais_eventos_agenda_pkey (OID = 107571) : 
--
ALTER TABLE ONLY locais_eventos_agenda
    ADD CONSTRAINT locais_eventos_agenda_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index locais_eventos_agenda_id_local_evento_fkey (OID = 107684) : 
--
ALTER TABLE ONLY locais_eventos_agenda
    ADD CONSTRAINT locais_eventos_agenda_id_local_evento_fkey
    FOREIGN KEY (id_local_evento) REFERENCES locais_eventos(id) MATCH FULL;
--
-- Definition for index eventos_id_local_evento_fkey (OID = 107689) : 
--
ALTER TABLE ONLY eventos
    ADD CONSTRAINT eventos_id_local_evento_fkey
    FOREIGN KEY (id_local_evento) REFERENCES locais_eventos(id);
--
-- Definition for index temas_eventos_id_usuario_fkey (OID = 107694) : 
--
ALTER TABLE ONLY temas_eventos
    ADD CONSTRAINT temas_eventos_id_usuario_fkey
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id);
--
-- Definition for index locais_eventos_agenda_id_evento_fkey (OID = 108024) : 
--
ALTER TABLE ONLY locais_eventos_agenda
    ADD CONSTRAINT locais_eventos_agenda_id_evento_fkey
    FOREIGN KEY (id_evento, ano_evento) REFERENCES eventos(id, ano);
--
-- Definition for index usuarios_agenda_pkey (OID = 108049) : 
--
ALTER TABLE ONLY usuarios_agenda
    ADD CONSTRAINT usuarios_agenda_pkey
    PRIMARY KEY (id, ano);
--
-- Definition for index usuarios_agenda_id_evento_fkey (OID = 108051) : 
--
ALTER TABLE ONLY usuarios_agenda
    ADD CONSTRAINT usuarios_agenda_id_evento_fkey
    FOREIGN KEY (id_evento, ano_evento) REFERENCES eventos(id, ano);
--
-- Definition for index usuarios_agenda_id_usuario_fkey (OID = 108056) : 
--
ALTER TABLE ONLY usuarios_agenda
    ADD CONSTRAINT usuarios_agenda_id_usuario_fkey
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id);
--
-- Comments
--
COMMENT ON SCHEMA public IS 'standard public schema';
	   